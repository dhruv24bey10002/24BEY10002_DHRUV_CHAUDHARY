package com.airport.management.config;

import com.airport.management.model.Booking;
import com.airport.management.model.Flight;
import com.airport.management.model.Passenger;
import com.airport.management.model.Staff;
import com.airport.management.repository.BookingRepository;
import com.airport.management.repository.FlightRepository;
import com.airport.management.repository.PassengerRepository;
import com.airport.management.repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private FlightRepository flightRepository;

    @Autowired
    private PassengerRepository passengerRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private StaffRepository staffRepository;

    @Override
    public void run(String... args) throws Exception {
        // Clear collections first so we guarantee fresh populated data
        System.out.println("Clearing old collections for fresh population...");
        bookingRepository.deleteAll();
        flightRepository.deleteAll();
        passengerRepository.deleteAll();
        staffRepository.deleteAll();

        // 1. Seed Passengers
        System.out.println("Populating passengers...");
        List<Passenger> passengers = Arrays.asList(
                new Passenger(null, "A1234567", "John", "Doe", "john.doe@email.com", "+1-555-0199", "Male", LocalDate.of(1990, 5, 15)),
                new Passenger(null, "B9876543", "Jane", "Smith", "jane.smith@email.com", "+1-555-0245", "Female", LocalDate.of(1988, 10, 22)),
                new Passenger(null, "Z7654321", "Rahul", "Sharma", "rahul.sharma@email.com", "+91-98765-43210", "Male", LocalDate.of(1995, 12, 5)),
                new Passenger(null, "Y8765432", "Priya", "Patel", "priya.patel@email.com", "+91-91234-56789", "Female", LocalDate.of(2000, 3, 30)),
                new Passenger(null, "C1122334", "Bob", "Johnson", "bob.j@email.com", "+1-555-0391", "Male", LocalDate.of(1985, 7, 14)),
                new Passenger(null, "D4455667", "Alice", "Brown", "alice.b@email.com", "+1-555-0422", "Female", LocalDate.of(1993, 2, 28)),
                new Passenger(null, "E7788990", "Charlie", "Davis", "charlie.d@email.com", "+1-555-0561", "Male", LocalDate.of(1978, 11, 3)),
                new Passenger(null, "F1212121", "Diana", "Prince", "diana.p@email.com", "+1-555-0900", "Female", LocalDate.of(1984, 8, 18)),
                new Passenger(null, "G3434343", "Bruce", "Wayne", "bruce.w@email.com", "+1-555-1000", "Male", LocalDate.of(1975, 4, 17)),
                new Passenger(null, "H5656565", "Clark", "Kent", "clark.k@email.com", "+1-555-2000", "Male", LocalDate.of(1980, 2, 29)),
                new Passenger(null, "J7878787", "Peter", "Parker", "peter.p@email.com", "+1-555-3000", "Male", LocalDate.of(2001, 8, 10)),
                new Passenger(null, "K9090909", "Tony", "Stark", "tony.s@email.com", "+1-555-4000", "Male", LocalDate.of(1970, 5, 29)),
                new Passenger(null, "L1313131", "Natasha", "Romanoff", "natasha.r@email.com", "+1-555-5000", "Female", LocalDate.of(1984, 11, 22)),
                new Passenger(null, "M1515151", "Steve", "Rogers", "steve.r@email.com", "+1-555-6000", "Male", LocalDate.of(1918, 7, 4)),
                new Passenger(null, "N1717171", "Wanda", "Maximoff", "wanda.m@email.com", "+1-555-7000", "Female", LocalDate.of(1989, 2, 10)),
                new Passenger(null, "P1818181", "Barry", "Allen", "barry.a@email.com", "+1-555-8000", "Male", LocalDate.of(1992, 9, 30)),
                new Passenger(null, "Q1919191", "Hal", "Jordan", "hal.j@email.com", "+1-555-8001", "Male", LocalDate.of(1980, 12, 18)),
                new Passenger(null, "R2020202", "Arthur", "Curry", "arthur.c@email.com", "+1-555-8002", "Male", LocalDate.of(1986, 1, 29)),
                new Passenger(null, "S2121212", "Victor", "Stone", "victor.s@email.com", "+1-555-8003", "Male", LocalDate.of(1994, 6, 15)),
                new Passenger(null, "T2222222", "Oliver", "Queen", "oliver.q@email.com", "+1-555-8004", "Male", LocalDate.of(1985, 5, 16)),
                new Passenger(null, "U2323232", "Lois", "Lane", "lois.l@email.com", "+1-555-8005", "Female", LocalDate.of(1981, 3, 2)),
                new Passenger(null, "V2424242", "Iris", "West", "iris.w@email.com", "+1-555-8006", "Female", LocalDate.of(1993, 6, 24)),
                new Passenger(null, "W2525252", "Felicity", "Smoak", "felicity.s@email.com", "+1-555-8007", "Female", LocalDate.of(1989, 7, 24)),
                new Passenger(null, "X2626262", "Merlin", "Emrys", "merlin@email.com", "+44-555-9000", "Male", LocalDate.of(1979, 10, 10))
        );
        passengers = passengerRepository.saveAll(passengers);
        System.out.println("Seeded 25 sample passengers.");

        // 2. Seed Flights
        System.out.println("Populating flights...");
        List<Flight> flights = Arrays.asList(
                new Flight(null, "AI-101", "Air India", "DEL", "BOM",
                        LocalDateTime.now().plusDays(1).withHour(10).withMinute(0).withSecond(0).withNano(0),
                        LocalDateTime.now().plusDays(1).withHour(12).withMinute(15).withSecond(0).withNano(0),
                        "Scheduled", "Gate A12", "Boeing 777"),
                new Flight(null, "EK-503", "Emirates", "BOM", "DXB",
                        LocalDateTime.now().withHour(22).withMinute(30).withSecond(0).withNano(0),
                        LocalDateTime.now().plusDays(1).withHour(0).withMinute(15).withSecond(0).withNano(0),
                        "Delayed", "Gate B3", "Airbus A380"),
                new Flight(null, "LH-761", "Lufthansa", "DEL", "FRA",
                        LocalDateTime.now().minusHours(2).withMinute(0).withSecond(0).withNano(0),
                        LocalDateTime.now().plusHours(6).withMinute(0).withSecond(0).withNano(0),
                        "Departed", "Gate C5", "Boeing 747"),
                new Flight(null, "SG-205", "SpiceJet", "DEL", "MAA",
                        LocalDateTime.now().plusHours(4).withMinute(0).withSecond(0).withNano(0),
                        LocalDateTime.now().plusHours(6).withMinute(45).withSecond(0).withNano(0),
                        "Cancelled", "Gate A4", "Boeing 737"),
                new Flight(null, "SQ-406", "Singapore Airlines", "BOM", "SIN",
                        LocalDateTime.now().plusHours(8).withMinute(0).withSecond(0).withNano(0),
                        LocalDateTime.now().plusHours(13).withMinute(30).withSecond(0).withNano(0),
                        "Scheduled", "Gate A10", "Airbus A350"),
                new Flight(null, "BA-142", "British Airways", "DEL", "LHR",
                        LocalDateTime.now().plusDays(2).withHour(6).withMinute(15).withSecond(0).withNano(0),
                        LocalDateTime.now().plusDays(2).withHour(11).withMinute(45).withSecond(0).withNano(0),
                        "Scheduled", "Gate B1", "Boeing 787"),
                new Flight(null, "UA-901", "United Airlines", "BOM", "EWR",
                        LocalDateTime.now().plusHours(12).withMinute(0).withSecond(0).withNano(0),
                        LocalDateTime.now().plusHours(26).withMinute(30).withSecond(0).withNano(0),
                        "Scheduled", "Gate C2", "Boeing 777"),
                new Flight(null, "AA-234", "American Airlines", "DEL", "JFK",
                        LocalDateTime.now().minusDays(1).withHour(22).withMinute(0),
                        LocalDateTime.now().minusDays(1).plusHours(15).withMinute(30),
                        "Landed", "Gate A8", "Boeing 777"),
                new Flight(null, "QF-082", "Qantas", "SIN", "SYD",
                        LocalDateTime.now().plusDays(1).withHour(18).withMinute(0),
                        LocalDateTime.now().plusDays(2).withHour(2).withMinute(30),
                        "Scheduled", "Gate T2", "Boeing 787"),
                new Flight(null, "CX-712", "Cathay Pacific", "BOM", "HKG",
                        LocalDateTime.now().plusHours(1).withMinute(30),
                        LocalDateTime.now().plusHours(7).withMinute(45),
                        "Scheduled", "Gate B8", "Airbus A330"),
                new Flight(null, "AF-226", "Air France", "BOM", "CDG",
                        LocalDateTime.now().plusDays(3).withHour(14).withMinute(0),
                        LocalDateTime.now().plusDays(3).withHour(20).withMinute(15),
                        "Scheduled", "Gate C4", "Boeing 777"),
                new Flight(null, "JL-036", "Japan Airlines", "DEL", "HND",
                        LocalDateTime.now().plusHours(10).withMinute(45),
                        LocalDateTime.now().plusHours(19).withMinute(15),
                        "Scheduled", "Gate A6", "Boeing 787"),
                new Flight(null, "KL-875", "KLM", "DEL", "AMS",
                        LocalDateTime.now().plusDays(1).withHour(3).withMinute(30),
                        LocalDateTime.now().plusDays(1).withHour(9).withMinute(10),
                        "Scheduled", "Gate B12", "Boeing 777"),
                new Flight(null, "MS-965", "EgyptAir", "BOM", "CAI",
                        LocalDateTime.now().plusHours(5).withMinute(15),
                        LocalDateTime.now().plusHours(11).withMinute(30),
                        "Scheduled", "Gate C10", "Airbus A320"),
                new Flight(null, "ET-602", "Ethiopian Airlines", "DEL", "ADD",
                        LocalDateTime.now().plusDays(2).withHour(1).withMinute(0),
                        LocalDateTime.now().plusDays(2).withHour(6).withMinute(45),
                        "Scheduled", "Gate A2", "Boeing 787")
        );
        flights = flightRepository.saveAll(flights);
        System.out.println("Seeded 15 sample flights.");

        // 3. Seed Bookings
        System.out.println("Populating bookings...");
        if (!flights.isEmpty() && passengers.size() >= 25) {
            Flight f1 = flights.get(0); // AI-101
            Flight f2 = flights.get(1); // EK-503
            Flight f3 = flights.get(2); // LH-761
            Flight f4 = flights.get(3); // SG-205 (Cancelled)
            Flight f5 = flights.get(4); // SQ-406
            Flight f6 = flights.get(5); // BA-142
            Flight f7 = flights.get(6); // UA-901
            Flight f8 = flights.get(7); // AA-234 (Landed)
            Flight f9 = flights.get(8); // QF-082
            Flight f10 = flights.get(9); // CX-712
            Flight f11 = flights.get(10); // AF-226
            Flight f12 = flights.get(11); // JL-036

            List<Booking> bookings = Arrays.asList(
                    new Booking(null, "PNR10293", passengers.get(0).getId(), f1.getId(), "12A", "Business", LocalDateTime.now().minusDays(2), 450.0, "Confirmed"),
                    new Booking(null, "PNR84729", passengers.get(1).getId(), f1.getId(), "14C", "Economy", LocalDateTime.now().minusDays(1), 150.0, "Confirmed"),
                    new Booking(null, "PNR93018", passengers.get(2).getId(), f2.getId(), "3B", "Business", LocalDateTime.now().minusHours(12), 620.0, "Confirmed"),
                    new Booking(null, "PNR77281", passengers.get(3).getId(), f3.getId(), "25F", "Economy", LocalDateTime.now().minusDays(3), 850.0, "CheckedIn"),
                    new Booking(null, "PNR38290", passengers.get(0).getId(), f4.getId(), "8D", "Economy", LocalDateTime.now().minusDays(1), 120.0, "Cancelled"),
                    new Booking(null, "PNR50607", passengers.get(4).getId(), f5.getId(), "1A", "First", LocalDateTime.now().minusDays(4), 1100.0, "Confirmed"),
                    new Booking(null, "PNR11223", passengers.get(5).getId(), f5.getId(), "18C", "Economy", LocalDateTime.now().minusDays(1), 320.0, "Confirmed"),
                    new Booking(null, "PNR44556", passengers.get(6).getId(), f6.getId(), "10F", "Business", LocalDateTime.now().minusDays(2), 950.0, "Confirmed"),
                    new Booking(null, "PNR77889", passengers.get(7).getId(), f7.getId(), "33A", "Economy", LocalDateTime.now().minusHours(8), 1250.0, "Confirmed"),
                    new Booking(null, "PNR99001", passengers.get(8).getId(), f8.getId(), "15B", "Economy", LocalDateTime.now().minusDays(5), 720.0, "CheckedIn"),
                    new Booking(null, "PNR99002", passengers.get(9).getId(), f8.getId(), "12C", "Business", LocalDateTime.now().minusDays(5), 1300.0, "CheckedIn"),
                    new Booking(null, "PNR88334", passengers.get(10).getId(), f1.getId(), "22D", "Economy", LocalDateTime.now().minusHours(4), 160.0, "Confirmed"),
                    new Booking(null, "PNR55112", passengers.get(11).getId(), f2.getId(), "4F", "Business", LocalDateTime.now().minusDays(1), 580.0, "Confirmed"),
                    new Booking(null, "PNR66778", passengers.get(12).getId(), f6.getId(), "32C", "Economy", LocalDateTime.now().minusDays(2), 390.0, "Confirmed"),
                    new Booking(null, "PNR22990", passengers.get(13).getId(), f7.getId(), "5A", "First", LocalDateTime.now().minusDays(3), 2500.0, "Confirmed"),
                    new Booking(null, "PNR10203", passengers.get(14).getId(), f9.getId(), "14B", "Economy", LocalDateTime.now().minusDays(2), 680.0, "Confirmed"),
                    new Booking(null, "PNR40506", passengers.get(15).getId(), f9.getId(), "10A", "Business", LocalDateTime.now().minusDays(1), 1200.0, "Confirmed"),
                    new Booking(null, "PNR70809", passengers.get(16).getId(), f10.getId(), "18D", "Economy", LocalDateTime.now().minusHours(5), 350.0, "Confirmed"),
                    new Booking(null, "PNR12131", passengers.get(17).getId(), f10.getId(), "8F", "Business", LocalDateTime.now().minusDays(2), 850.0, "Confirmed"),
                    new Booking(null, "PNR14151", passengers.get(18).getId(), f11.getId(), "20A", "Economy", LocalDateTime.now().minusDays(4), 490.0, "Confirmed"),
                    new Booking(null, "PNR16171", passengers.get(19).getId(), f11.getId(), "11D", "Business", LocalDateTime.now().minusDays(3), 1150.0, "Confirmed"),
                    new Booking(null, "PNR18191", passengers.get(20).getId(), f12.getId(), "22A", "Economy", LocalDateTime.now().minusDays(1), 580.0, "Confirmed"),
                    new Booking(null, "PNR20212", passengers.get(21).getId(), f12.getId(), "3C", "First", LocalDateTime.now().minusDays(2), 2900.0, "Confirmed"),
                    new Booking(null, "PNR22232", passengers.get(22).getId(), f1.getId(), "16A", "Economy", LocalDateTime.now().minusHours(2), 150.0, "Confirmed"),
                    new Booking(null, "PNR24252", passengers.get(23).getId(), f2.getId(), "28F", "Economy", LocalDateTime.now().minusDays(1), 210.0, "Confirmed")
            );
            bookingRepository.saveAll(bookings);
            System.out.println("Seeded 25 sample bookings.");
        }

        // 4. Seed Staff
        System.out.println("Populating staff...");
        List<Staff> staffList = Arrays.asList(
                new Staff(null, "ST-001", "Dakshal", "Srivastava", "Pilot", "dakshal.s@airport.com", "+91-98765-11111", 150000.0, "Flight Operations"),
                new Staff(null, "ST-002", "Pranay", "Sharma", "Cabin Crew", "pranay.s@airport.com", "+91-98765-22222", 65000.0, "Inflight Services"),
                new Staff(null, "ST-003", "Khateeb", "Ahmed", "Maintenance", "khateeb.a@airport.com", "+91-98765-33333", 55000.0, "Ground Operations"),
                new Staff(null, "ST-004", "Abdullah", "Abbas", "Security", "abdullah.a@airport.com", "+91-98765-44444", 70000.0, "Airport Security"),
                new Staff(null, "ST-005", "Mohammad", "Anwar", "Pilot", "mohammad.a@airport.com", "+91-98765-55555", 145000.0, "Flight Operations"),
                new Staff(null, "ST-006", "Siddhi", "", "Cabin Crew", "siddhi@airport.com", "+91-98765-66666", 62000.0, "Inflight Services"),
                new Staff(null, "ST-007", "Harshit", "Yadav", "Security", "harshit.y@airport.com", "+91-98765-77777", 68000.0, "Airport Security"),
                new Staff(null, "ST-008", "Ronit", "Mishra", "Pilot", "ronit.m@airport.com", "+91-98765-88888", 140000.0, "Flight Operations"),
                
                // IT & Administration Academic Developer Detail
                new Staff(null, "ST-ADMIN", "Dhruv", "Chaudhary", "Admin", "dhruv.c@airport.com", "+91-24BEY10002", 200000.0, "IT & Administration")
        );
        staffRepository.saveAll(staffList);
        System.out.println("Seeded 9 sample staff members.");
        System.out.println("Database population completed successfully!");
    }
}
