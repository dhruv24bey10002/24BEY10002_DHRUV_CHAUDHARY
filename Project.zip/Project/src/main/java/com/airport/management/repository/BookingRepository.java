package com.airport.management.repository;

import com.airport.management.model.Booking;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BookingRepository extends MongoRepository<Booking, String> {
    Optional<Booking> findByBookingReference(String bookingReference);
    List<Booking> findByPassengerId(String passengerId);
    List<Booking> findByFlightId(String flightId);
    List<Booking> findByFlightIdAndSeatNumberAndStatusNot(String flightId, String seatNumber, String status);
}
