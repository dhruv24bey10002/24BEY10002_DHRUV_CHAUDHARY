package com.airport.management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Document(collection = "staff")
public class Staff {
    @Id
    private String id;

    @NotBlank(message = "Staff ID is required")
    private String staffId;

    @NotBlank(message = "First name is required")
    private String firstName;

    @NotBlank(message = "Last name is required")
    private String lastName;

    @NotBlank(message = "Role is required")
    private String role; // Pilot, Cabin Crew, Maintenance, Security, Admin

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;

    @NotBlank(message = "Phone number is required")
    private String phone;

    @NotNull(message = "Salary is required")
    @Positive(message = "Salary must be positive")
    private Double salary;

    @NotBlank(message = "Department is required")
    private String department;

    // Default Constructor
    public Staff() {}

    // All-args Constructor
    public Staff(String id, String staffId, String firstName, String lastName, String role, String email,
                 String phone, Double salary, String department) {
        this.id = id;
        this.staffId = staffId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.role = role;
        this.email = email;
        this.phone = phone;
        this.salary = salary;
        this.department = department;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getStaffId() { return staffId; }
    public void setStaffId(String staffId) { this.staffId = staffId; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public Double getSalary() { return salary; }
    public void setSalary(Double salary) { this.salary = salary; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    // Static Builder Implementation
    public static StaffBuilder builder() {
        return new StaffBuilder();
    }

    public static class StaffBuilder {
        private String id;
        private String staffId;
        private String firstName;
        private String lastName;
        private String role;
        private String email;
        private String phone;
        private Double salary;
        private String department;

        public StaffBuilder id(String id) { this.id = id; return this; }
        public StaffBuilder staffId(String staffId) { this.staffId = staffId; return this; }
        public StaffBuilder firstName(String firstName) { this.firstName = firstName; return this; }
        public StaffBuilder lastName(String lastName) { this.lastName = lastName; return this; }
        public StaffBuilder role(String role) { this.role = role; return this; }
        public StaffBuilder email(String email) { this.email = email; return this; }
        public StaffBuilder phone(String phone) { this.phone = phone; return this; }
        public StaffBuilder salary(Double salary) { this.salary = salary; return this; }
        public StaffBuilder department(String department) { this.department = department; return this; }

        public Staff build() {
            return new Staff(id, staffId, firstName, lastName, role, email, phone, salary, department);
        }
    }
}
