package com.airport.management.service;

import com.airport.management.model.Passenger;
import com.airport.management.repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PassengerService {

    @Autowired
    private PassengerRepository passengerRepository;

    public Passenger createPassenger(Passenger passenger) {
        if (passengerRepository.findByPassportNumber(passenger.getPassportNumber()).isPresent()) {
            throw new IllegalArgumentException("Passenger with passport number already exists: " + passenger.getPassportNumber());
        }
        return passengerRepository.save(passenger);
    }

    public List<Passenger> getAllPassengers() {
        return passengerRepository.findAll();
    }

    public Optional<Passenger> getPassengerById(String id) {
        return passengerRepository.findById(id);
    }

    public Optional<Passenger> getPassengerByPassport(String passportNumber) {
        return passengerRepository.findByPassportNumber(passportNumber);
    }

    public Passenger updatePassenger(String id, Passenger passengerDetails) {
        Passenger passenger = passengerRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Passenger not found with id: " + id));

        // Verify passport uniqueness if changed
        if (!passenger.getPassportNumber().equals(passengerDetails.getPassportNumber())) {
            if (passengerRepository.findByPassportNumber(passengerDetails.getPassportNumber()).isPresent()) {
                throw new IllegalArgumentException("Passport number already in use: " + passengerDetails.getPassportNumber());
            }
        }

        passenger.setPassportNumber(passengerDetails.getPassportNumber());
        passenger.setFirstName(passengerDetails.getFirstName());
        passenger.setLastName(passengerDetails.getLastName());
        passenger.setEmail(passengerDetails.getEmail());
        passenger.setPhoneNumber(passengerDetails.getPhoneNumber());
        passenger.setGender(passengerDetails.getGender());
        passenger.setDateOfBirth(passengerDetails.getDateOfBirth());

        return passengerRepository.save(passenger);
    }

    public void deletePassenger(String id) {
        if (!passengerRepository.existsById(id)) {
            throw new IllegalArgumentException("Passenger not found with id: " + id);
        }
        passengerRepository.deleteById(id);
    }
}
