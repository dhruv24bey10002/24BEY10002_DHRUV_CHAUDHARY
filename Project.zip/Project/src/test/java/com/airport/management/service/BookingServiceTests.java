package com.airport.management.service;

import com.airport.management.model.Booking;
import com.airport.management.model.Flight;
import com.airport.management.model.Passenger;
import com.airport.management.repository.BookingRepository;
import com.airport.management.repository.FlightRepository;
import com.airport.management.repository.PassengerRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class BookingServiceTests {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private FlightRepository flightRepository;

    @Autowired
    private PassengerRepository passengerRepository;

    @Autowired
    private BookingService bookingService;

    private Flight testFlight;
    private Passenger testPassenger;
    private Booking inputBooking;

    @BeforeEach
    void setUp() {
        // Clean up any leftovers first
        bookingRepository.deleteAll();
        flightRepository.deleteAll();
        passengerRepository.deleteAll();

        // Create test Flight
        testFlight = Flight.builder()
                .flightNumber("TEST-101")
                .airline("Test Airline")
                .departureAirport("DEL")
                .arrivalAirport("BOM")
                .departureTime(LocalDateTime.now().plusDays(1))
                .arrivalTime(LocalDateTime.now().plusDays(1).plusHours(2))
                .status("Scheduled")
                .gate("Gate T1")
                .aircraftType("B737")
                .build();
        testFlight = flightRepository.save(testFlight);

        // Create test Passenger
        testPassenger = Passenger.builder()
                .firstName("Test")
                .lastName("User")
                .email("test.user@email.com")
                .phoneNumber("+1-555-9999")
                .gender("Male")
                .passportNumber("TESTPASS1")
                .dateOfBirth(LocalDate.of(1999, 1, 1))
                .build();
        testPassenger = passengerRepository.save(testPassenger);

        // Prepare input booking details (without reference/status/date to check backend generation)
        inputBooking = Booking.builder()
                .flightId(testFlight.getId())
                .passengerId(testPassenger.getId())
                .seatNumber("10A")
                .bookingClass("Economy")
                .price(200.0)
                .build();
    }

    @AfterEach
    void tearDown() {
        // Clean up database after each test to leave it in a clean state
        bookingRepository.deleteAll();
        flightRepository.deleteAll();
        passengerRepository.deleteAll();
    }

    @Test
    void testCreateBooking_Success() {
        // Act
        Booking savedBooking = bookingService.createBooking(inputBooking);

        // Assert
        assertNotNull(savedBooking);
        assertNotNull(savedBooking.getId());
        assertNotNull(savedBooking.getBookingReference());
        assertTrue(savedBooking.getBookingReference().startsWith("PNR"));
        assertEquals("Confirmed", savedBooking.getStatus());
        assertNotNull(savedBooking.getBookingDate());

        // Verify in DB
        Booking fetched = bookingRepository.findById(savedBooking.getId()).orElse(null);
        assertNotNull(fetched);
        assertEquals("10A", fetched.getSeatNumber());
    }

    @Test
    void testCreateBooking_FlightNotFound() {
        // Arrange
        inputBooking.setFlightId("non-existent-flight-id");

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            bookingService.createBooking(inputBooking);
        });
        assertTrue(exception.getMessage().contains("Invalid Flight ID"));
    }

    @Test
    void testCreateBooking_PassengerNotFound() {
        // Arrange
        inputBooking.setPassengerId("non-existent-passenger-id");

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            bookingService.createBooking(inputBooking);
        });
        assertTrue(exception.getMessage().contains("Invalid Passenger ID"));
    }

    @Test
    void testCreateBooking_FlightCancelled() {
        // Arrange
        testFlight.setStatus("Cancelled");
        flightRepository.save(testFlight);

        // Act & Assert
        IllegalStateException exception = assertThrows(IllegalStateException.class, () -> {
            bookingService.createBooking(inputBooking);
        });
        assertTrue(exception.getMessage().contains("Cannot book tickets for a cancelled flight"));
    }

    @Test
    void testCreateBooking_SeatAlreadyOccupied() {
        // Arrange: first booking succeeds
        bookingService.createBooking(inputBooking);

        // Prepare a second booking for the same seat and flight
        Passenger anotherPassenger = Passenger.builder()
                .firstName("Another")
                .lastName("User")
                .email("another.user@email.com")
                .phoneNumber("+1-555-8888")
                .gender("Female")
                .passportNumber("TESTPASS2")
                .dateOfBirth(LocalDate.of(1995, 5, 5))
                .build();
        anotherPassenger = passengerRepository.save(anotherPassenger);

        Booking duplicateSeatBooking = Booking.builder()
                .flightId(testFlight.getId())
                .passengerId(anotherPassenger.getId())
                .seatNumber("10A") // same seat
                .bookingClass("Business")
                .price(400.0)
                .build();

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            bookingService.createBooking(duplicateSeatBooking);
        });
        assertTrue(exception.getMessage().contains("already occupied"));
    }
}
