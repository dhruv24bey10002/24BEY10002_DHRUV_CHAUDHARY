package com.airport.management.service;

import com.airport.management.model.Booking;
import com.airport.management.model.Flight;
import com.airport.management.model.Passenger;
import com.airport.management.repository.BookingRepository;
import com.airport.management.repository.FlightRepository;
import com.airport.management.repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private FlightRepository flightRepository;

    @Autowired
    private PassengerRepository passengerRepository;

    public Booking createBooking(Booking booking) {
        // 1. Verify Flight exists
        Flight flight = flightRepository.findById(booking.getFlightId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid Flight ID: " + booking.getFlightId()));

        // 2. Verify Passenger exists
        passengerRepository.findById(booking.getPassengerId())
                .orElseThrow(() -> new IllegalArgumentException("Invalid Passenger ID: " + booking.getPassengerId()));

        // 3. Check if flight is Cancelled
        if ("Cancelled".equalsIgnoreCase(flight.getStatus())) {
            throw new IllegalStateException("Cannot book tickets for a cancelled flight.");
        }

        // 4. Check seat availability (make sure it's not already booked and active)
        List<Booking> existingBookings = bookingRepository.findByFlightIdAndSeatNumberAndStatusNot(
                booking.getFlightId(), booking.getSeatNumber(), "Cancelled"
        );
        if (!existingBookings.isEmpty()) {
            throw new IllegalArgumentException("Seat " + booking.getSeatNumber() + " is already occupied on flight " + flight.getFlightNumber());
        }

        // 5. Generate PNR booking reference if not present
        if (booking.getBookingReference() == null || booking.getBookingReference().trim().isEmpty()) {
            booking.setBookingReference("PNR" + UUID.randomUUID().toString().substring(0, 5).toUpperCase());
        }

        // 6. Set booking date if not present
        if (booking.getBookingDate() == null) {
            booking.setBookingDate(LocalDateTime.now());
        }

        // 7. Ensure status is Confirmed
        if (booking.getStatus() == null || booking.getStatus().trim().isEmpty()) {
            booking.setStatus("Confirmed");
        }

        return bookingRepository.save(booking);
    }

    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public Optional<Booking> getBookingById(String id) {
        return bookingRepository.findById(id);
    }

    public Optional<Booking> getBookingByReference(String bookingReference) {
        return bookingRepository.findByBookingReference(bookingReference);
    }

    public List<Booking> getBookingsByPassenger(String passengerId) {
        return bookingRepository.findByPassengerId(passengerId);
    }

    public List<Booking> getBookingsByFlight(String flightId) {
        return bookingRepository.findByFlightId(flightId);
    }

    public Booking updateBookingStatus(String id, String status) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found with id: " + id));

        if ("CheckedIn".equalsIgnoreCase(status) && "Cancelled".equalsIgnoreCase(booking.getStatus())) {
            throw new IllegalStateException("Cannot check-in a cancelled booking.");
        }

        booking.setStatus(status);
        return bookingRepository.save(booking);
    }

    public void cancelBooking(String id) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found with id: " + id));
        booking.setStatus("Cancelled");
        bookingRepository.save(booking);
    }
}
