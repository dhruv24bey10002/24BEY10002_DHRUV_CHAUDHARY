package com.airport.management.repository;

import com.airport.management.model.Flight;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FlightRepository extends MongoRepository<Flight, String> {
    Optional<Flight> findByFlightNumber(String flightNumber);
    List<Flight> findByStatus(String status);
    List<Flight> findByAirline(String airline);
    List<Flight> findByDepartureAirportAndArrivalAirport(String departureAirport, String arrivalAirport);
}
