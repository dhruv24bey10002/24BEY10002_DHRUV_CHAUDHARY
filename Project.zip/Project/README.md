# Airport Management System (AeroManager)

An academic, pure **console-based CLI application** built using **Spring Boot**, **MongoDB**, and **Spring Data MongoDB** designed to handle daily airport operations such as managing flights, passengers, staff, and ticket bookings. 

This application runs as a lightweight terminal-based tool, completely bypassing web containers, and interfaces directly with the user via a structured, interactive console menu.

---

## Developer / Student Credentials
- **Name:** Dhruv Chaudhary
- **Enrollment Number:** 24BEY10002
- **University:** VIT Bhopal University
- **Branch:** Computer Science Engineering
- **Academic Year:** 2026-2027

---

## Technology Stack & Versions
- **Language:** Java 17+ (compatible up to Java 26)
- **Framework:** Spring Boot 3.4.3 (Web service and interactive CLI running concurrently)
- **Embedded Web Server:** Apache Tomcat on port `8080`
- **API Documentation:** Springdoc OpenAPI / Swagger UI
- **Database:** MongoDB
- **Build Tool:** Maven (packaged with Maven Wrapper `mvnw`)
- **CLI Interface:** Standard System Input (`Scanner`) with a structured menu and ANSI colorized table layouts.

---

## System Architecture & Collections

The database schema consists of four primary collections in MongoDB:

### 1. Flights (`flights`)
Stores details of scheduled, departed, arrived, delayed, or cancelled flights.
- Fields: `id`, `flightNumber`, `airline`, `departureAirport`, `arrivalAirport`, `departureTime`, `arrivalTime`, `status`, `gate`, `aircraftType`.

### 2. Passengers (`passengers`)
Stores passenger records including passport numbers, contact info, and registration details.
- Fields: `id`, `passportNumber`, `firstName`, `lastName`, `email`, `phoneNumber`, `gender`, `dateOfBirth`.

### 3. Bookings (`bookings`)
Handles flight reservations. When bookings are made, the backend validates passenger and flight existence and ensures seats are not double-booked.
- Fields: `id`, `bookingReference` (PNR Reference, e.g., PNR12345), `passengerId`, `flightId`, `seatNumber`, `bookingClass`, `bookingDate`, `price`, `status`.

### 4. Staff (`staff`)
Tracks airport and airline employees including pilots, cabin crew, security, and administrative members.
- Fields: `id`, `staffId` (custom, e.g. ST-001), `firstName`, `lastName`, `role`, `email`, `phone`, `salary`, `department`.

---

## Interactive CLI Menu Structure

When launched, the console application will show a main menu:

```
==========================================================================================
                              MAIN MENU
==========================================================================================
1. Manage Flights
2. Manage Passengers
3. Manage Bookings
4. Manage Staff
5. View Airport Operational Statistics
6. Exit
==========================================================================================
Enter choice (1-6): 
```

### Submenu Operations

#### 1. Flights Management:
- **Add New Flight:** Prompts for flight number, airline, airports, schedule times, gate, and aircraft. Sets status automatically to `Scheduled`.
- **List All Flights:** Displays a formatted table with flight details.
- **Search Flights by Route:** Filter flights by entering departure and arrival codes.
- **Update Flight Status:** Select a flight and change status to `Delayed`, `Departed`, `Landed`, `Cancelled`, etc.
- **Delete Flight:** Delete a flight record by ID.

#### 2. Passengers Directory:
- **Register New Passenger:** Input details including passport, birthdate, and contact info.
- **List All Passengers:** Displays passenger profiles in a tabular format.
- **Search Passenger by Passport:** Locate full traveler records using passport search.
- **Delete Passenger Profile:** Remove passenger profile by ID.

#### 3. Bookings Management:
- **Book a Ticket:** Automatically displays flights and passengers, prompts for selections, inputs seat & class, validates seat availability, calculates fare, creates booking, and generates a unique PNR.
- **Cancel Booking:** Releases reserved seats by setting status to `Cancelled`.
- **View Booking by PNR:** Look up reservation details by entering PNR.
- **List All Bookings:** Lists all ticket bookings.

#### 4. Staff Registry:
- **Add Staff Member:** Hire employee (Pilot, Cabin Crew, Maintenance, Security, Admin, etc.)
- **List All Staff:** Displays employee directory.
- **Update Staff Details:** Update custom employee details or department.
- **Remove Staff Member:** Fire staff member by ID.

#### 5. Airport Statistics:
- Computes operational metrics: Total flights scheduled, count of active/delayed/cancelled flights, total registered passengers, total tickets issued, and total revenue metrics.

---

## Database Seeding (Sample Data)
To ensure the system works out-of-the-box, a `DataInitializer` class is configured. When the application starts up, if the MongoDB database is empty, the system automatically inserts:
- **15 sample flights** (with different statuses: Scheduled, Delayed, Departed, Landed, Cancelled)
- **25 sample passengers**
- **25 sample bookings** (linking flights and passengers, validating seat availability)
- **9 sample staff members** (with updated personnel such as pilots, cabin crew, security, and maintenance)

---

## REST API & Swagger UI Documentation

The application exposes a robust REST API alongside the interactive console menu. You can interact with the endpoints using Swagger UI or Postman.

### Swagger UI Access
* **Swagger UI Dashboard:** [http://localhost:8080/swagger-ui/index.html](http://localhost:8080/swagger-ui/index.html)
* **OpenAPI Specification (JSON):** [http://localhost:8080/v3/api-docs](http://localhost:8080/v3/api-docs)

### Postman Integration
We have provided a pre-configured Postman Collection file directly in the project root: [AeroManager.postman_collection.json](file:///e:/MongoDB%20Task/Project/AeroManager.postman_collection.json).

To import and use it in Postman:
1. Open Postman, click **Import** in the top-left corner.
2. Select or drag-and-drop the [AeroManager.postman_collection.json](file:///e:/MongoDB%20Task/Project/AeroManager.postman_collection.json) file.
3. Once imported, you will see the **AeroManager** collection with organized folders for **Flights**, **Passengers**, **Bookings**, and **Staff**.
4. The collection is configured with a collection variable `baseUrl = http://localhost:8080`.
5. Alternatively, you can click **Import** -> **Link** in Postman and paste the live OpenAPI schema URL: `http://localhost:8080/v3/api-docs` to automatically generate the collection.

### Core Endpoints

#### 1. Flights API (`/api/flights`)
* `GET /api/flights` - Retrieve all flights
* `GET /api/flights/{id}` - Get flight details by Database ID
* `GET /api/flights/number/{flightNumber}` - Find flight by flight number
* `POST /api/flights` - Register a new flight
* `PUT /api/flights/{id}` - Update flight details
* `PATCH /api/flights/{id}/status?status={status}` - Update flight status
* `DELETE /api/flights/{id}` - Delete a flight record

#### 2. Passengers API (`/api/passengers`)
* `GET /api/passengers` - Retrieve all registered passengers
* `GET /api/passengers/{id}` - Get passenger profile by Database ID
* `GET /api/passengers/passport/{passportNumber}` - Get passenger details by passport
* `POST /api/passengers` - Register a new passenger
* `PUT /api/passengers/{id}` - Update passenger details
* `DELETE /api/passengers/{id}` - Remove passenger profile

#### 3. Bookings API (`/api/bookings`)
* `GET /api/bookings` - List all ticket bookings
* `GET /api/bookings/{id}` - Get booking details by Database ID
* `GET /api/bookings/reference/{bookingReference}` - Look up booking by PNR reference
* `POST /api/bookings` - Book a new flight ticket (executes capacity, passenger, and seat occupancy checks)
* `PATCH /api/bookings/{id}/status?status={status}` - Update booking status (e.g. CheckedIn)
* `DELETE /api/bookings/{id}` - Cancel booking (releases seat, marks status as `Cancelled`)

#### 4. Staff API (`/api/staff`)
* `GET /api/staff` - List all airport employees
* `GET /api/staff/{id}` - Get staff member details by Database ID
* `POST /api/staff` - Add a new staff member to the registry
* `PUT /api/staff/{id}` - Update staff details
* `DELETE /api/staff/{id}` - Remove employee record

---

## Instructions to Run & Test

### Prerequisites
1. **Java Development Kit (JDK):** JDK 17 or higher.
2. **MongoDB:** A local MongoDB instance running on `mongodb://localhost:27017` (or change the connection string in `src/main/resources/application.properties`).

### 1. Compile and Run Tests
To verify all unit/integration tests compile and pass, run:
```bash
# Windows
.\mvnw.cmd clean test

# Linux / macOS
chmod +x mvnw
./mvnw clean test
```

### 2. Run the Application (Dual Mode)
Start the application:
```bash
# Windows
.\mvnw.cmd spring-boot:run

# Linux / macOS
./mvnw spring-boot:run
```
Once started:
* The **Interactive CLI** will boot directly in your terminal where you launched the command.
* The **REST Web Service** will be listening on `http://localhost:8080`. You can keep the CLI open and simultaneously test the APIs using Swagger UI or Postman.
