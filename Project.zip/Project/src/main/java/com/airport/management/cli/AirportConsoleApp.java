package com.airport.management.cli;

import com.airport.management.model.Booking;
import com.airport.management.model.Flight;
import com.airport.management.model.Passenger;
import com.airport.management.model.Staff;
import com.airport.management.service.BookingService;
import com.airport.management.service.FlightService;
import com.airport.management.service.PassengerService;
import com.airport.management.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

@Component
public class AirportConsoleApp implements CommandLineRunner {

    @Autowired
    private FlightService flightService;

    @Autowired
    private PassengerService passengerService;

    @Autowired
    private BookingService bookingService;

    @Autowired
    private StaffService staffService;

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    // ANSI Escape Codes for Colors
    private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_RED = "\u001B[31m";
    private static final String ANSI_GREEN = "\u001B[32m";
    private static final String ANSI_YELLOW = "\u001B[33m";
    private static final String ANSI_BLUE = "\u001B[34m";
    private static final String ANSI_PURPLE = "\u001B[35m";
    private static final String ANSI_CYAN = "\u001B[36m";
    
    // Bold ANSI Codes
    private static final String ANSI_BOLD_RED = "\u001B[1;31m";
    private static final String ANSI_BOLD_GREEN = "\u001B[1;32m";
    private static final String ANSI_BOLD_YELLOW = "\u001B[1;33m";
    private static final String ANSI_BOLD_BLUE = "\u001B[1;34m";
    private static final String ANSI_BOLD_PURPLE = "\u001B[1;35m";
    private static final String ANSI_BOLD_CYAN = "\u001B[1;36m";

    private String getFlightStatusColor(String status) {
        if (status == null) return ANSI_RESET;
        switch (status.trim()) {
            case "Scheduled": return ANSI_BOLD_YELLOW;
            case "Delayed": return ANSI_BOLD_PURPLE;
            case "Departed": return ANSI_BOLD_BLUE;
            case "Landed": return ANSI_BOLD_GREEN;
            case "Cancelled": return ANSI_BOLD_RED;
            default: return ANSI_RESET;
        }
    }

    private String getBookingStatusColor(String status) {
        if (status == null) return ANSI_RESET;
        switch (status.trim()) {
            case "Confirmed": return ANSI_BOLD_GREEN;
            case "CheckedIn": return ANSI_BOLD_BLUE;
            case "Cancelled": return ANSI_BOLD_RED;
            default: return ANSI_RESET;
        }
    }

    private boolean isTestEnvironment() {
        for (StackTraceElement element : Thread.currentThread().getStackTrace()) {
            if (element.getClassName().startsWith("org.junit.") ||
                element.getClassName().startsWith("org.springframework.test.")) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void run(String... args) throws Exception {
        // Prevent launching CLI when running unit/integration tests
        if (isTestEnvironment()) {
            return;
        }

        Scanner scanner = new Scanner(System.in);
        System.out.println("\nInitializing AeroManager Database Connection...");
        Thread.sleep(500); // short pause for visual effect

        boolean running = true;
        while (running) {
            printHeader("MAIN MENU");
            System.out.println("1. Manage Flights");
            System.out.println("2. Manage Passengers");
            System.out.println("3. Manage Bookings");
            System.out.println("4. Manage Staff");
            System.out.println("5. View Airport Operational Statistics");
            System.out.println("6. Exit");
            System.out.print("\nEnter choice (1-6): ");

            String choice;
            try {
                choice = scanner.nextLine().trim();
            } catch (Exception e) {
                System.out.println("\nNo interactive console detected. Continuing in API-only web server mode.");
                break;
            }
            switch (choice) {
                case "1":
                    flightsMenu(scanner);
                    break;
                case "2":
                    passengersMenu(scanner);
                    break;
                case "3":
                    bookingsMenu(scanner);
                    break;
                case "4":
                    staffMenu(scanner);
                    break;
                case "5":
                    viewStatistics();
                    break;
                case "6":
                    System.out.println("\nThank you for using AeroManager. Goodbye!");
                    running = false;
                    break;
                default:
                    System.out.println("\n[ERROR] Invalid choice. Please select 1-6.");
            }
        }
    }

    // ==========================================
    // FLIGHTS SECTION
    // ==========================================
    private void flightsMenu(Scanner scanner) {
        boolean back = false;
        while (!back) {
            printHeader("FLIGHTS MANAGEMENT");
            System.out.println("1. Add New Flight");
            System.out.println("2. List All Flights");
            System.out.println("3. Search Flights by Route");
            System.out.println("4. Update Flight Status");
            System.out.println("5. Delete Flight");
            System.out.println("6. Return to Main Menu");
            System.out.print("\nEnter choice (1-6): ");

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    addNewFlight(scanner);
                    break;
                case "2":
                    listAllFlights();
                    break;
                case "3":
                    searchFlightsByRoute(scanner);
                    break;
                case "4":
                    updateFlightStatus(scanner);
                    break;
                case "5":
                    deleteFlight(scanner);
                    break;
                case "6":
                    back = true;
                    break;
                default:
                    System.out.println("\n[ERROR] Invalid choice.");
            }
        }
    }

    private void addNewFlight(Scanner scanner) {
        printHeader("ADD NEW FLIGHT");
        System.out.print("Enter Flight Number (e.g. AI-101): ");
        String flightNum = scanner.nextLine().trim();
        System.out.print("Enter Airline (e.g. Air India): ");
        String airline = scanner.nextLine().trim();
        System.out.print("Enter Departure Airport Code (e.g. DEL): ");
        String depAirport = scanner.nextLine().trim().toUpperCase();
        System.out.print("Enter Arrival Airport Code (e.g. BOM): ");
        String arrAirport = scanner.nextLine().trim().toUpperCase();
        
        LocalDateTime depTime = readDateTime(scanner, "Enter Departure Time (yyyy-MM-dd HH:mm): ");
        LocalDateTime arrTime = readDateTime(scanner, "Enter Arrival Time (yyyy-MM-dd HH:mm): ");
        
        System.out.print("Enter Gate (e.g. Gate A12): ");
        String gate = scanner.nextLine().trim();
        System.out.print("Enter Aircraft Type (e.g. Boeing 777): ");
        String aircraft = scanner.nextLine().trim();

        Flight flight = Flight.builder()
                .flightNumber(flightNum)
                .airline(airline)
                .departureAirport(depAirport)
                .arrivalAirport(arrAirport)
                .departureTime(depTime)
                .arrivalTime(arrTime)
                .status("Scheduled")
                .gate(gate)
                .aircraftType(aircraft)
                .build();

        try {
            flightService.createFlight(flight);
            System.out.println("\n[SUCCESS] Flight " + flightNum + " registered successfully!");
        } catch (Exception e) {
            System.out.println("\n[ERROR] Failed to register flight: " + e.getMessage());
        }
    }

    private void listAllFlights() {
        printHeader("FLIGHT DIRECTORY");
        List<Flight> flights = flightService.getAllFlights();
        if (flights.isEmpty()) {
            System.out.println("No flights found in database.");
            return;
        }
        System.out.printf("%-24s | %-8s | %-22s | %-5s -> %-5s | %-16s | %-16s | %-10s | %-10s\n",
                "ID", "FLIGHT", "AIRLINE", "FROM", "TO", "DEPARTURE", "ARRIVAL", "STATUS", "GATE");
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------");
        for (Flight f : flights) {
            System.out.printf("%-24s | %-8s | %-22s | %-5s -> %-5s | %-16s | %-16s | ",
                    f.getId(), f.getFlightNumber(), f.getAirline(), f.getDepartureAirport(), f.getArrivalAirport(),
                    f.getDepartureTime().format(DATETIME_FORMATTER), f.getArrivalTime().format(DATETIME_FORMATTER));
            
            System.out.print(getFlightStatusColor(f.getStatus()));
            System.out.printf("%-10s", f.getStatus());
            System.out.print(ANSI_RESET);
            
            System.out.printf(" | %-10s\n", f.getGate());
        }
    }

    private void searchFlightsByRoute(Scanner scanner) {
        printHeader("SEARCH FLIGHTS BY ROUTE");
        System.out.print("Enter Departure Airport Code: ");
        String dep = scanner.nextLine().trim().toUpperCase();
        System.out.print("Enter Arrival Airport Code: ");
        String arr = scanner.nextLine().trim().toUpperCase();

        List<Flight> flights = flightService.getFlightsByRoute(dep, arr);
        if (flights.isEmpty()) {
            System.out.println("\nNo flights found matching route " + dep + " -> " + arr);
            return;
        }
        System.out.println("\nFlights found for route " + dep + " -> " + arr + ":");
        for (Flight f : flights) {
            System.out.println("- Flight " + f.getFlightNumber() + " (" + f.getAirline() + ") | Gate: " + f.getGate() + " | Status: " + f.getStatus());
        }
    }

    private void updateFlightStatus(Scanner scanner) {
        printHeader("UPDATE FLIGHT STATUS");
        listAllFlights();
        System.out.print("\nEnter Flight ID to update: ");
        String id = scanner.nextLine().trim();
        System.out.print("Enter New Status (Scheduled, Delayed, Departed, Landed, Cancelled): ");
        String status = scanner.nextLine().trim();

        try {
            flightService.updateFlightStatus(id, status);
            System.out.println("\n[SUCCESS] Flight status updated successfully.");
        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }
    }

    private void deleteFlight(Scanner scanner) {
        printHeader("DELETE FLIGHT");
        listAllFlights();
        System.out.print("\nEnter Flight ID to delete: ");
        String id = scanner.nextLine().trim();

        try {
            flightService.deleteFlight(id);
            System.out.println("\n[SUCCESS] Flight record deleted.");
        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }
    }

    // ==========================================
    // PASSENGERS SECTION
    // ==========================================
    private void passengersMenu(Scanner scanner) {
        boolean back = false;
        while (!back) {
            printHeader("PASSENGERS DIRECTORY");
            System.out.println("1. Register New Passenger");
            System.out.println("2. List All Passengers");
            System.out.println("3. Search Passenger by Passport");
            System.out.println("4. Delete Passenger Profile");
            System.out.println("5. Return to Main Menu");
            System.out.print("\nEnter choice (1-5): ");

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    registerPassenger(scanner);
                    break;
                case "2":
                    listAllPassengers();
                    break;
                case "3":
                    searchPassengerByPassport(scanner);
                    break;
                case "4":
                    deletePassenger(scanner);
                    break;
                case "5":
                    back = true;
                    break;
                default:
                    System.out.println("\n[ERROR] Invalid choice.");
            }
        }
    }

    private void registerPassenger(Scanner scanner) {
        printHeader("REGISTER NEW PASSENGER");
        System.out.print("Enter Passport Number: ");
        String passport = scanner.nextLine().trim();
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine().trim();
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine().trim();
        System.out.print("Enter Email Address: ");
        String email = scanner.nextLine().trim();
        System.out.print("Enter Phone Number: ");
        String phone = scanner.nextLine().trim();
        System.out.print("Enter Gender (Male/Female/Other): ");
        String gender = scanner.nextLine().trim();
        
        LocalDate dob = readDate(scanner, "Enter Date of Birth (yyyy-MM-dd): ");

        Passenger passenger = Passenger.builder()
                .passportNumber(passport)
                .firstName(firstName)
                .lastName(lastName)
                .email(email)
                .phoneNumber(phone)
                .gender(gender)
                .dateOfBirth(dob)
                .build();

        try {
            passengerService.createPassenger(passenger);
            System.out.println("\n[SUCCESS] Passenger registered successfully with ID: " + passenger.getId());
        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }
    }

    private void listAllPassengers() {
        printHeader("PASSENGER DIRECTORY");
        List<Passenger> passengers = passengerService.getAllPassengers();
        if (passengers.isEmpty()) {
            System.out.println("No passengers found in database.");
            return;
        }
        System.out.printf("%-24s | %-12s | %-20s | %-24s | %-15s | %-10s\n",
                "ID", "PASSPORT", "NAME", "EMAIL", "PHONE", "DOB");
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------");
        for (Passenger p : passengers) {
            System.out.printf("%-24s | %-12s | %-20s | %-24s | %-15s | %-10s\n",
                    p.getId(), p.getPassportNumber(), p.getFirstName() + " " + p.getLastName(),
                    p.getEmail(), p.getPhoneNumber(), p.getDateOfBirth().format(DATE_FORMATTER));
        }
    }

    private void searchPassengerByPassport(Scanner scanner) {
        printHeader("SEARCH PASSENGER");
        System.out.print("Enter Passport Number: ");
        String passport = scanner.nextLine().trim();

        Optional<Passenger> passenger = passengerService.getPassengerByPassport(passport);
        if (passenger.isPresent()) {
            Passenger p = passenger.get();
            System.out.println("\nPassenger Found:");
            System.out.println("- Name: " + p.getFirstName() + " " + p.getLastName());
            System.out.println("- Email: " + p.getEmail());
            System.out.println("- Phone: " + p.getPhoneNumber());
            System.out.println("- Gender: " + p.getGender());
            System.out.println("- DOB: " + p.getDateOfBirth());
        } else {
            System.out.println("\nNo passenger found with passport: " + passport);
        }
    }

    private void deletePassenger(Scanner scanner) {
        printHeader("DELETE PASSENGER PROFILE");
        listAllPassengers();
        System.out.print("\nEnter Passenger ID to delete: ");
        String id = scanner.nextLine().trim();

        try {
            passengerService.deletePassenger(id);
            System.out.println("\n[SUCCESS] Passenger profile removed.");
        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }
    }

    // ==========================================
    // BOOKINGS SECTION
    // ==========================================
    private void bookingsMenu(Scanner scanner) {
        boolean back = false;
        while (!back) {
            printHeader("BOOKINGS MANAGEMENT");
            System.out.println("1. Book a Ticket");
            System.out.println("2. Cancel Booking");
            System.out.println("3. View Booking by PNR");
            System.out.println("4. List All Bookings");
            System.out.println("5. Return to Main Menu");
            System.out.print("\nEnter choice (1-5): ");

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    bookTicket(scanner);
                    break;
                case "2":
                    cancelBooking(scanner);
                    break;
                case "3":
                    viewBookingByPnr(scanner);
                    break;
                case "4":
                    listAllBookings();
                    break;
                case "5":
                    back = true;
                    break;
                default:
                    System.out.println("\n[ERROR] Invalid choice.");
            }
        }
    }

    private void bookTicket(Scanner scanner) {
        printHeader("BOOK FLIGHT TICKET");
        System.out.println("\n--- Flight List ---");
        listAllFlights();
        System.out.print("\nEnter Flight ID to book: ");
        String flightId = scanner.nextLine().trim();

        System.out.println("\n--- Passenger List ---");
        listAllPassengers();
        System.out.print("\nEnter Passenger ID: ");
        String passengerId = scanner.nextLine().trim();

        System.out.print("Enter Seat Number (e.g. 14A): ");
        String seat = scanner.nextLine().trim();
        System.out.print("Enter Booking Class (Economy, Business, First): ");
        String bookingClass = scanner.nextLine().trim();
        
        double price = 0.0;
        boolean validPrice = false;
        while (!validPrice) {
            System.out.print("Enter Ticket Price ($): ");
            try {
                price = Double.parseDouble(scanner.nextLine().trim());
                if (price > 0) validPrice = true;
                else System.out.println("[ERROR] Price must be positive.");
            } catch (NumberFormatException e) {
                System.out.println("[ERROR] Invalid numeric format.");
            }
        }

        Booking booking = Booking.builder()
                .flightId(flightId)
                .passengerId(passengerId)
                .seatNumber(seat)
                .bookingClass(bookingClass)
                .price(price)
                .build();

        try {
            Booking saved = bookingService.createBooking(booking);
            System.out.println("\n[SUCCESS] Ticket booked successfully!");
            System.out.println("Generated PNR Reference: " + saved.getBookingReference());
        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }
    }

    private void cancelBooking(Scanner scanner) {
        printHeader("CANCEL TICKET BOOKING");
        listAllBookings();
        System.out.print("\nEnter Booking ID to cancel: ");
        String id = scanner.nextLine().trim();

        try {
            bookingService.cancelBooking(id);
            System.out.println("\n[SUCCESS] Ticket cancelled. Seat released.");
        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }
    }

    private void viewBookingByPnr(Scanner scanner) {
        printHeader("VIEW BOOKING BY PNR");
        System.out.print("Enter Booking PNR Reference (e.g. PNR-XXXXX): ");
        String pnr = scanner.nextLine().trim().toUpperCase();

        Optional<Booking> bookingOpt = bookingService.getBookingByReference(pnr);
        if (bookingOpt.isPresent()) {
            Booking b = bookingOpt.get();
            System.out.println("\nBooking Details:");
            System.out.println("- Reference (PNR): " + b.getBookingReference());
            System.out.println("- Passenger ID: " + b.getPassengerId());
            System.out.println("- Flight ID: " + b.getFlightId());
            System.out.println("- Seat Number: " + b.getSeatNumber());
            System.out.println("- Class: " + b.getBookingClass());
            System.out.println("- Price Paid: $" + b.getPrice());
            System.out.println("- Date: " + b.getBookingDate().format(DATETIME_FORMATTER));
            System.out.println("- Status: " + b.getStatus());
        } else {
            System.out.println("\nNo booking found with PNR: " + pnr);
        }
    }

    private void listAllBookings() {
        printHeader("BOOKINGS REGISTRY");
        List<Booking> bookings = bookingService.getAllBookings();
        if (bookings.isEmpty()) {
            System.out.println("No ticket bookings found in database.");
            return;
        }
        System.out.printf("%-24s | %-12s | %-24s | %-24s | %-6s | %-10s | %-16s | %-10s\n",
                "ID", "PNR REF", "PASSENGER ID", "FLIGHT ID", "SEAT", "CLASS", "DATE", "STATUS");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------");
        for (Booking b : bookings) {
            System.out.printf("%-24s | %-12s | %-24s | %-24s | %-6s | %-10s | %-16s | ",
                    b.getId(), b.getBookingReference(), b.getPassengerId(), b.getFlightId(),
                    b.getSeatNumber(), b.getBookingClass(), b.getBookingDate().format(DATETIME_FORMATTER));
            
            System.out.print(getBookingStatusColor(b.getStatus()));
            System.out.printf("%-10s", b.getStatus());
            System.out.print(ANSI_RESET);
            System.out.println();
        }
    }

    // ==========================================
    // STAFF SECTION
    // ==========================================
    private void staffMenu(Scanner scanner) {
        boolean back = false;
        while (!back) {
            printHeader("AIRPORT STAFF REGISTRY");
            System.out.println("1. Add Staff Member");
            System.out.println("2. List All Staff");
            System.out.println("3. Update Staff details");
            System.out.println("4. Remove Staff Member");
            System.out.println("5. Return to Main Menu");
            System.out.print("\nEnter choice (1-5): ");

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    addStaffMember(scanner);
                    break;
                case "2":
                    listAllStaff();
                    break;
                case "3":
                    updateStaffMember(scanner);
                    break;
                case "4":
                    removeStaffMember(scanner);
                    break;
                case "5":
                    back = true;
                    break;
                default:
                    System.out.println("\n[ERROR] Invalid choice.");
            }
        }
    }

    private void addStaffMember(Scanner scanner) {
        printHeader("ADD STAFF MEMBER");
        System.out.print("Enter Employee ID (e.g. ST-005): ");
        String empId = scanner.nextLine().trim();
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine().trim();
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine().trim();
        System.out.print("Enter Role (Pilot, Cabin Crew, Maintenance, Security, Admin): ");
        String role = scanner.nextLine().trim();
        System.out.print("Enter Email Address: ");
        String email = scanner.nextLine().trim();
        System.out.print("Enter Phone Number: ");
        String phone = scanner.nextLine().trim();
        
        double salary = 0.0;
        boolean validSalary = false;
        while (!validSalary) {
            System.out.print("Enter Salary ($): ");
            try {
                salary = Double.parseDouble(scanner.nextLine().trim());
                if (salary > 0) validSalary = true;
                else System.out.println("[ERROR] Salary must be positive.");
            } catch (NumberFormatException e) {
                System.out.println("[ERROR] Invalid numeric format.");
            }
        }
        
        System.out.print("Enter Department: ");
        String department = scanner.nextLine().trim();

        Staff s = Staff.builder()
                .staffId(empId)
                .firstName(firstName)
                .lastName(lastName)
                .role(role)
                .email(email)
                .phone(phone)
                .salary(salary)
                .department(department)
                .build();

        try {
            staffService.createStaff(s);
            System.out.println("\n[SUCCESS] Staff member added successfully.");
        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }
    }

    private void listAllStaff() {
        printHeader("STAFF DIRECTORY");
        List<Staff> staffList = staffService.getAllStaff();
        if (staffList.isEmpty()) {
            System.out.println("No staff records found in database.");
            return;
        }
        System.out.printf("%-24s | %-10s | %-20s | %-14s | %-24s | %-12s | %-24s\n",
                "ID", "EMP ID", "NAME", "ROLE", "EMAIL", "SALARY", "DEPARTMENT");
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------");
        for (Staff s : staffList) {
            System.out.printf("%-24s | %-10s | %-20s | %-14s | %-24s | $%-11.2f | %-24s\n",
                    s.getId(), s.getStaffId(), s.getFirstName() + " " + s.getLastName(),
                    s.getRole(), s.getEmail(), s.getSalary(), s.getDepartment());
        }
    }

    private void updateStaffMember(Scanner scanner) {
        printHeader("UPDATE STAFF DETAILS");
        listAllStaff();
        System.out.print("\nEnter Mongo Database ID of staff to update: ");
        String id = scanner.nextLine().trim();
        
        // Find existing
        Optional<Staff> opt = staffService.getStaffById(id);
        if (opt.isEmpty()) {
            System.out.println("\n[ERROR] Staff member not found.");
            return;
        }
        Staff staff = opt.get();
        System.out.println("\nUpdating " + staff.getFirstName() + " " + staff.getLastName() + ". Press enter to keep existing values.");

        System.out.print("Emp ID [" + staff.getStaffId() + "]: ");
        String empId = scanner.nextLine().trim();
        if (!empId.isEmpty()) staff.setStaffId(empId);

        System.out.print("First Name [" + staff.getFirstName() + "]: ");
        String firstName = scanner.nextLine().trim();
        if (!firstName.isEmpty()) staff.setFirstName(firstName);

        System.out.print("Last Name [" + staff.getLastName() + "]: ");
        String lastName = scanner.nextLine().trim();
        if (!lastName.isEmpty()) staff.setLastName(lastName);

        System.out.print("Role [" + staff.getRole() + "]: ");
        String role = scanner.nextLine().trim();
        if (!role.isEmpty()) staff.setRole(role);

        System.out.print("Email [" + staff.getEmail() + "]: ");
        String email = scanner.nextLine().trim();
        if (!email.isEmpty()) staff.setEmail(email);

        System.out.print("Phone [" + staff.getPhone() + "]: ");
        String phone = scanner.nextLine().trim();
        if (!phone.isEmpty()) staff.setPhone(phone);

        System.out.print("Salary [" + staff.getSalary() + "]: ");
        String salStr = scanner.nextLine().trim();
        if (!salStr.isEmpty()) {
            try {
                staff.setSalary(Double.parseDouble(salStr));
            } catch (NumberFormatException e) {
                System.out.println("[WARNING] Invalid salary format. Keeping original.");
            }
        }

        System.out.print("Department [" + staff.getDepartment() + "]: ");
        String dept = scanner.nextLine().trim();
        if (!dept.isEmpty()) staff.setDepartment(dept);

        try {
            staffService.updateStaff(id, staff);
            System.out.println("\n[SUCCESS] Staff registry updated successfully.");
        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }
    }

    private void removeStaffMember(Scanner scanner) {
        printHeader("REMOVE STAFF MEMBER");
        listAllStaff();
        System.out.print("\nEnter Staff Database ID to remove: ");
        String id = scanner.nextLine().trim();

        try {
            staffService.deleteStaff(id);
            System.out.println("\n[SUCCESS] Staff registry record deleted.");
        } catch (Exception e) {
            System.out.println("\n[ERROR] " + e.getMessage());
        }
    }

    // ==========================================
    // STATISTICS SECTION
    // ==========================================
    private void viewStatistics() {
        printHeader("OPERATIONAL STATISTICS");
        List<Flight> flights = flightService.getAllFlights();
        List<Passenger> passengers = passengerService.getAllPassengers();
        List<Booking> bookings = bookingService.getAllBookings();
        List<Staff> staff = staffService.getAllStaff();

        long activeFlights = flights.stream().filter(f -> !"Landed".equalsIgnoreCase(f.getStatus()) && !"Cancelled".equalsIgnoreCase(f.getStatus())).count();
        long delayedFlights = flights.stream().filter(f -> "Delayed".equalsIgnoreCase(f.getStatus())).count();
        long cancelledFlights = flights.stream().filter(f -> "Cancelled".equalsIgnoreCase(f.getStatus())).count();
        
        double revenue = bookings.stream()
                .filter(b -> !"Cancelled".equalsIgnoreCase(b.getStatus()))
                .mapToDouble(Booking::getPrice)
                .sum();

        System.out.println("Flight Indicators:");
        System.out.println("- Total Flights Scheduled: " + flights.size());
        System.out.println("- Active Flights (In-Air/Pending): " + activeFlights);
        System.out.println("- Delayed Flights: " + delayedFlights);
        System.out.println("- Cancelled Flights: " + cancelledFlights);
        System.out.println("----------------------------------------------");
        System.out.println("Airport Registries:");
        System.out.println("- Total Registered Passengers: " + passengers.size());
        System.out.println("- Active Staff Registry: " + staff.size());
        System.out.println("- Total Tickets Issued: " + bookings.size());
        System.out.println("----------------------------------------------");
        System.out.printf("Financial metrics:\n");
        System.out.printf("- Total Revenue Generated: $%.2f\n", revenue);
        System.out.println("==============================================");
    }

    // ==========================================
    // UTILITY METHODS
    // ==========================================
    private void printHeader(String title) {
        System.out.println(ANSI_BOLD_CYAN + "\n==========================================================================================");
        System.out.println("                              " + title);
        System.out.println("==========================================================================================" + ANSI_RESET);
    }

    private LocalDateTime readDateTime(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String val = scanner.nextLine().trim();
            try {
                return LocalDateTime.parse(val, DATETIME_FORMATTER);
            } catch (DateTimeParseException e) {
                System.out.println("[ERROR] Invalid date-time format. Please use 'yyyy-MM-dd HH:mm'.");
            }
        }
    }

    private LocalDate readDate(Scanner scanner, String prompt) {
        while (true) {
            System.out.print(prompt);
            String val = scanner.nextLine().trim();
            try {
                return LocalDate.parse(val, DATE_FORMATTER);
            } catch (DateTimeParseException e) {
                System.out.println("[ERROR] Invalid date format. Please use 'yyyy-MM-dd'.");
            }
        }
    }
}
