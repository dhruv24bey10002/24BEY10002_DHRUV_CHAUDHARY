package com.airport.management.repository;

import com.airport.management.model.Staff;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StaffRepository extends MongoRepository<Staff, String> {
    Optional<Staff> findByStaffId(String staffId);
    List<Staff> findByRole(String role);
    List<Staff> findByDepartment(String department);
}
