package com.airport.management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.time.LocalDateTime;

@Document(collection = "bookings")
public class Booking {
    @Id
    private String id;

    private String bookingReference; // E.g., PNR code

    @NotBlank(message = "Passenger ID is required")
    private String passengerId;

    @NotBlank(message = "Flight ID is required")
    private String flightId;

    @NotBlank(message = "Seat number is required")
    private String seatNumber;

    @NotBlank(message = "Booking class is required")
    private String bookingClass; // Economy, Business, First

    private LocalDateTime bookingDate;

    @NotNull(message = "Ticket price is required")
    @Positive(message = "Price must be positive")
    private Double price;

    private String status; // Confirmed, CheckedIn, Cancelled

    // Default Constructor
    public Booking() {}

    // All-args Constructor
    public Booking(String id, String bookingReference, String passengerId, String flightId, String seatNumber,
                   String bookingClass, LocalDateTime bookingDate, Double price, String status) {
        this.id = id;
        this.bookingReference = bookingReference;
        this.passengerId = passengerId;
        this.flightId = flightId;
        this.seatNumber = seatNumber;
        this.bookingClass = bookingClass;
        this.bookingDate = bookingDate;
        this.price = price;
        this.status = status;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getBookingReference() { return bookingReference; }
    public void setBookingReference(String bookingReference) { this.bookingReference = bookingReference; }

    public String getPassengerId() { return passengerId; }
    public void setPassengerId(String passengerId) { this.passengerId = passengerId; }

    public String getFlightId() { return flightId; }
    public void setFlightId(String flightId) { this.flightId = flightId; }

    public String getSeatNumber() { return seatNumber; }
    public void setSeatNumber(String seatNumber) { this.seatNumber = seatNumber; }

    public String getBookingClass() { return bookingClass; }
    public void setBookingClass(String bookingClass) { this.bookingClass = bookingClass; }

    public LocalDateTime getBookingDate() { return bookingDate; }
    public void setBookingDate(LocalDateTime bookingDate) { this.bookingDate = bookingDate; }

    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    // Static Builder Implementation
    public static BookingBuilder builder() {
        return new BookingBuilder();
    }

    public static class BookingBuilder {
        private String id;
        private String bookingReference;
        private String passengerId;
        private String flightId;
        private String seatNumber;
        private String bookingClass;
        private LocalDateTime bookingDate;
        private Double price;
        private String status;

        public BookingBuilder id(String id) { this.id = id; return this; }
        public BookingBuilder bookingReference(String bookingReference) { this.bookingReference = bookingReference; return this; }
        public BookingBuilder passengerId(String passengerId) { this.passengerId = passengerId; return this; }
        public BookingBuilder flightId(String flightId) { this.flightId = flightId; return this; }
        public BookingBuilder seatNumber(String seatNumber) { this.seatNumber = seatNumber; return this; }
        public BookingBuilder bookingClass(String bookingClass) { this.bookingClass = bookingClass; return this; }
        public BookingBuilder bookingDate(LocalDateTime bookingDate) { this.bookingDate = bookingDate; return this; }
        public BookingBuilder price(Double price) { this.price = price; return this; }
        public BookingBuilder status(String status) { this.status = status; return this; }

        public Booking build() {
            return new Booking(id, bookingReference, passengerId, flightId, seatNumber, bookingClass, bookingDate, price, status);
        }
    }
}
