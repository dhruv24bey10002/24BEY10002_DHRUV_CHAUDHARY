package com.airport.management.service;

import com.airport.management.model.Staff;
import com.airport.management.repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StaffService {

    @Autowired
    private StaffRepository staffRepository;

    public Staff createStaff(Staff staff) {
        if (staffRepository.findByStaffId(staff.getStaffId()).isPresent()) {
            throw new IllegalArgumentException("Staff member with staffId already exists: " + staff.getStaffId());
        }
        return staffRepository.save(staff);
    }

    public List<Staff> getAllStaff() {
        return staffRepository.findAll();
    }

    public Optional<Staff> getStaffById(String id) {
        return staffRepository.findById(id);
    }

    public Optional<Staff> getStaffByStaffId(String staffId) {
        return staffRepository.findByStaffId(staffId);
    }

    public Staff updateStaff(String id, Staff staffDetails) {
        Staff staff = staffRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Staff not found with id: " + id));

        // Verify staff ID uniqueness if changed
        if (!staff.getStaffId().equals(staffDetails.getStaffId())) {
            if (staffRepository.findByStaffId(staffDetails.getStaffId()).isPresent()) {
                throw new IllegalArgumentException("Staff ID already in use: " + staffDetails.getStaffId());
            }
        }

        staff.setStaffId(staffDetails.getStaffId());
        staff.setFirstName(staffDetails.getFirstName());
        staff.setLastName(staffDetails.getLastName());
        staff.setRole(staffDetails.getRole());
        staff.setEmail(staffDetails.getEmail());
        staff.setPhone(staffDetails.getPhone());
        staff.setSalary(staffDetails.getSalary());
        staff.setDepartment(staffDetails.getDepartment());

        return staffRepository.save(staff);
    }

    public void deleteStaff(String id) {
        if (!staffRepository.existsById(id)) {
            throw new IllegalArgumentException("Staff member not found with id: " + id);
        }
        staffRepository.deleteById(id);
    }

    public List<Staff> getStaffByRole(String role) {
        return staffRepository.findByRole(role);
    }

    public List<Staff> getStaffByDepartment(String department) {
        return staffRepository.findByDepartment(department);
    }
}
