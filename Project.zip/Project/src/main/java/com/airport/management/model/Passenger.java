package com.airport.management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

@Document(collection = "passengers")
public class Passenger {
    @Id
    private String id;

    @NotBlank(message = "Passport number is required")
    private String passportNumber;

    @NotBlank(message = "First name is required")
    private String firstName;

    @NotBlank(message = "Last name is required")
    private String lastName;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;

    @NotBlank(message = "Phone number is required")
    private String phoneNumber;

    @NotBlank(message = "Gender is required")
    private String gender;

    @NotNull(message = "Date of birth is required")
    private LocalDate dateOfBirth;

    // Default Constructor
    public Passenger() {}

    // All-args Constructor
    public Passenger(String id, String passportNumber, String firstName, String lastName, String email,
                     String phoneNumber, String gender, LocalDate dateOfBirth) {
        this.id = id;
        this.passportNumber = passportNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getPassportNumber() { return passportNumber; }
    public void setPassportNumber(String passportNumber) { this.passportNumber = passportNumber; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }

    // Static Builder Implementation
    public static PassengerBuilder builder() {
        return new PassengerBuilder();
    }

    public static class PassengerBuilder {
        private String id;
        private String passportNumber;
        private String firstName;
        private String lastName;
        private String email;
        private String phoneNumber;
        private String gender;
        private LocalDate dateOfBirth;

        public PassengerBuilder id(String id) { this.id = id; return this; }
        public PassengerBuilder passportNumber(String passportNumber) { this.passportNumber = passportNumber; return this; }
        public PassengerBuilder firstName(String firstName) { this.firstName = firstName; return this; }
        public PassengerBuilder lastName(String lastName) { this.lastName = lastName; return this; }
        public PassengerBuilder email(String email) { this.email = email; return this; }
        public PassengerBuilder phoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; return this; }
        public PassengerBuilder gender(String gender) { this.gender = gender; return this; }
        public PassengerBuilder dateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; return this; }

        public Passenger build() {
            return new Passenger(id, passportNumber, firstName, lastName, email, phoneNumber, gender, dateOfBirth);
        }
    }
}
