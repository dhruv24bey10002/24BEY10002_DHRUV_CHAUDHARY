package com.airport.management.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Document(collection = "flights")
public class Flight {
    @Id
    private String id;

    @NotBlank(message = "Flight number is required")
    private String flightNumber;

    @NotBlank(message = "Airline is required")
    private String airline;

    @NotBlank(message = "Departure airport is required")
    private String departureAirport;

    @NotBlank(message = "Arrival airport is required")
    private String arrivalAirport;

    @NotNull(message = "Departure time is required")
    private LocalDateTime departureTime;

    @NotNull(message = "Arrival time is required")
    private LocalDateTime arrivalTime;

    @NotBlank(message = "Flight status is required")
    private String status; // Scheduled, Delayed, Cancelled, Departed, Landed

    @NotBlank(message = "Gate is required")
    private String gate;

    @NotBlank(message = "Aircraft type is required")
    private String aircraftType;

    // Default Constructor
    public Flight() {}

    // All-args Constructor
    public Flight(String id, String flightNumber, String airline, String departureAirport, String arrivalAirport,
                  LocalDateTime departureTime, LocalDateTime arrivalTime, String status, String gate, String aircraftType) {
        this.id = id;
        this.flightNumber = flightNumber;
        this.airline = airline;
        this.departureAirport = departureAirport;
        this.arrivalAirport = arrivalAirport;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        this.status = status;
        this.gate = gate;
        this.aircraftType = aircraftType;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getFlightNumber() { return flightNumber; }
    public void setFlightNumber(String flightNumber) { this.flightNumber = flightNumber; }

    public String getAirline() { return airline; }
    public void setAirline(String airline) { this.airline = airline; }

    public String getDepartureAirport() { return departureAirport; }
    public void setDepartureAirport(String departureAirport) { this.departureAirport = departureAirport; }

    public String getArrivalAirport() { return arrivalAirport; }
    public void setArrivalAirport(String arrivalAirport) { this.arrivalAirport = arrivalAirport; }

    public LocalDateTime getDepartureTime() { return departureTime; }
    public void setDepartureTime(LocalDateTime departureTime) { this.departureTime = departureTime; }

    public LocalDateTime getArrivalTime() { return arrivalTime; }
    public void setArrivalTime(LocalDateTime arrivalTime) { this.arrivalTime = arrivalTime; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getGate() { return gate; }
    public void setGate(String gate) { this.gate = gate; }

    public String getAircraftType() { return aircraftType; }
    public void setAircraftType(String aircraftType) { this.aircraftType = aircraftType; }

    // Static Builder Implementation
    public static FlightBuilder builder() {
        return new FlightBuilder();
    }

    public static class FlightBuilder {
        private String id;
        private String flightNumber;
        private String airline;
        private String departureAirport;
        private String arrivalAirport;
        private LocalDateTime departureTime;
        private LocalDateTime arrivalTime;
        private String status;
        private String gate;
        private String aircraftType;

        public FlightBuilder id(String id) { this.id = id; return this; }
        public FlightBuilder flightNumber(String flightNumber) { this.flightNumber = flightNumber; return this; }
        public FlightBuilder airline(String airline) { this.airline = airline; return this; }
        public FlightBuilder departureAirport(String departureAirport) { this.departureAirport = departureAirport; return this; }
        public FlightBuilder arrivalAirport(String arrivalAirport) { this.arrivalAirport = arrivalAirport; return this; }
        public FlightBuilder departureTime(LocalDateTime departureTime) { this.departureTime = departureTime; return this; }
        public FlightBuilder arrivalTime(LocalDateTime arrivalTime) { this.arrivalTime = arrivalTime; return this; }
        public FlightBuilder status(String status) { this.status = status; return this; }
        public FlightBuilder gate(String gate) { this.gate = gate; return this; }
        public FlightBuilder aircraftType(String aircraftType) { this.aircraftType = aircraftType; return this; }

        public Flight build() {
            return new Flight(id, flightNumber, airline, departureAirport, arrivalAirport,
                    departureTime, arrivalTime, status, gate, aircraftType);
        }
    }
}
